package com.shop.Service;

public class UserDetailsService {
}
