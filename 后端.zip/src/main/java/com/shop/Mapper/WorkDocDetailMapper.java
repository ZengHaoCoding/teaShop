package com.shop.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop.Entity.WorkDocDetail;
import org.springframework.stereotype.Repository;

@Repository
public interface WorkDocDetailMapper extends BaseMapper<WorkDocDetail> {
}
