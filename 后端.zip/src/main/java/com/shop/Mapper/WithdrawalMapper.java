package com.shop.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop.Entity.Withdrawal;
import org.springframework.stereotype.Repository;

@Repository
public interface WithdrawalMapper extends BaseMapper<Withdrawal> {
}
