package com.shop.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop.Entity.Goods;
import org.springframework.stereotype.Repository;

@Repository
public interface GoodsMapper extends BaseMapper<Goods> {
}
