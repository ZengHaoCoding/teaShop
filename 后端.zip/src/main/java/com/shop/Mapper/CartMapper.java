package com.shop.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop.Entity.Cart;
import org.springframework.stereotype.Repository;

@Repository
public interface CartMapper extends BaseMapper<Cart> {
}
