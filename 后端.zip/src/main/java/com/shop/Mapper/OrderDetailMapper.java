package com.shop.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop.Entity.OrderDetail;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderDetailMapper extends BaseMapper<OrderDetail> {
}
